import AxiosInstance from './AxiosInstance';




const PostsApis = {
  getPostList(){
    
  }
  


  postLogout(isLogon) {
    return AxiosInstance({
      url: 'member/logout',
      method: 'post',
      headers: {
        'Content-Type': 'application/json',
      },
      data: { isLogon },
    });
  },
};

export default PostsApis;
