import React from 'react';
import { useSelector } from 'react-redux';
import styles from './Top.module.css';

const Top = () => {
  const { number, username } = useSelector((store) => store);

  return (
    <div className={styles.sub_container}>
      <h1>Top</h1>
      번호:{number}
      이름:{username}
    </div>
  );
};

export default Top;
