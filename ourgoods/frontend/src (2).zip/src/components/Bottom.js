import React from 'react';
import styles from './Bottom.module.css';
import { useDispatch } from 'react-redux';
import { increase } from '../store';

const Bottom = () => {
  const dispatcher = useDispatch();

  return (
    <div className={styles.sub_container}>
      <h1>Bottom</h1>
      <button onClick={() => dispatcher(increase('cos'))}>증가</button>
      <button onClick={() => dispatcher({ type: 'DECREMENT' })}>감소</button>
    </div>
  );
};
export default Bottom;
