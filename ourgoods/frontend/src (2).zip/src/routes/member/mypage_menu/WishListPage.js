import React from "react";
import { Grid } from "../../../elements";
import styles from "../myPage.module.css";

const WishListPage = () => {
  return (
    <div className={styles.container}>
      <Grid width="1024px" margin="auto">
        <div>wishlist</div>   
      </Grid>
    </div>
  );
};

export default WishListPage;

