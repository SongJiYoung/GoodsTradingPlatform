import React, { useState, useEffect } from 'react';
import { Button } from 'react-bootstrap';
import { useParams, useNavigate } from 'react-router-dom';

const Post = () => {
  const id = useParams();
  const navigate = useNavigate();

  console.log(id);

  const [post, setPost] = useState({
    id: '',
    title: '',
    author: '',
  });

  useEffect(() => {
    //Route path="/post/:id"이므로 빈곳에 fetch를날리면 제대로 요청이감
    fetch('')
      .then((res) => res.json())
      .then((res) => {
        setPost(res);
      });
  }, []);

  const deletePost = () => {
    fetch('', {
      method: 'DELETE',
      headers: {
        'Content-type': 'application/json;charset=utf-8',
      },
      body: JSON.stringify(id),
    })
      .then((res) => res.text())
      .then((res) => {
        if (res === 'ok') {
          navigate('/postlist');
        } else {
          alert('삭제실패');
        }
      });
  };

  const updatePost = (id) => {
    navigate('/updatepost/' + id);
  };

  return (
    <div>
      <h1>굿즈 상세보기</h1>
      <hr />
      <h3>{post.author}</h3>
      <h1>{post.title}</h1>
      <Button variant="secondary" onClick={() => updatePost(post.id)}>
        수정
      </Button>{' '}
      <Button
        variant="secondary"
        onClick={() => {
          deletePost();
        }}
      >
        삭제
      </Button>{' '}
    </div>
  );
};
export default Post;
