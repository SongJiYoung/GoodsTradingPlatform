import React, { useEffect } from 'react';
import { useState, useRef } from 'react';
import styles from './PostListPage.module.css';
import PostItem from '../../components/PostItem';

const PostListPage = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    fetch('/post')
      .then((res) => res.json())
      .then((res) => {
        console.log(res);
        setPosts(res);
      });
  }, []);

  return (
    <div>
      <h1>상품 리스트 보기</h1>
      {posts.map((post) => (
        <PostItem key={post.id} post={post} />
      ))}
    </div>
  );
};

export default PostListPage;
