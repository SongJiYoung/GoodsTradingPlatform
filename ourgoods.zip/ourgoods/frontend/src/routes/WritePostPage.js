import React from 'react';

const WritePostPage = () => <div>글쓰기</div>;

export default WritePostPage;
