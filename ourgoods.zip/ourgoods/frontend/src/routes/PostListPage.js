import React from 'react';

const PostListPage = () => <div>포스트 리스트</div>;

export default PostListPage;
