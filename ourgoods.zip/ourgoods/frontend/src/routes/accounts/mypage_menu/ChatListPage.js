import React from "react";
import { Grid } from "../../../elements";
import styles from "../myPage.module.css";

const ChatListPage = () => {
  return (
    <div className={styles.container}>
      <Grid width="1024px" margin="auto">
        <div>chatlist</div>   
      </Grid>
    </div>
  );
};

export default ChatListPage;

