package com.ourgoods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OurgoodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurgoodsApplication.class, args);
	}

}
