package com.ourgoods;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OurgoodsApplicationTests {

	@Test
	void contextLoads() {
	}

}
